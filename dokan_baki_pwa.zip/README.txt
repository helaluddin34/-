# দোকানের বাকি হিসাব Pro — PWA

ফাইলগুলো একটি HTTPS static hosting-এ প্রকাশ করলে এটি মোবাইলের Home Screen-এ App হিসেবে Install করা যাবে।

ফাইল:
- index.html
- manifest.json
- sw.js
- icon.svg

নোট:
- হিসাব ব্রাউজারের localStorage-এ থাকে।
- ফোন/ব্রাউজার বদলানোর আগে Backup ডাউনলোড করে রাখুন।
- স্থায়ী URL পেতে GitHub Pages, Netlify, Vercel ইত্যাদি static hosting ব্যবহার করা যাবে।
